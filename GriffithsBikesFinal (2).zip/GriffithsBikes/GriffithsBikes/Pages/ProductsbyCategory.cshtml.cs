using GriffithsBikes.Data;
using Microsoft.AspNetCore.Mvc;
using GriffithsBikes.Entities;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DynamicProductPageRecording.Entities;
using System.Linq;

namespace GriffithsBikes.Pages
{

    public class ProductsbyCategoryModel : PageModel
    {
        //Do the following to inject our Database context into our Razor Page model.
        private readonly ClassDbContext _classDbContext;
        public string Fullname { get; set; }
        public string Message { get; set; }
        public ProductsbyCategoryModel(ClassDbContext classDbContext)
        {
            _classDbContext = classDbContext;
        }

        public int CurrentCategory { get; set; }
        public IList<GriffithsBikesProductMaster> productsbycategory { get; set; }



        public async Task OnGetAsync(int ProductCategoryID)
        {
            CurrentCategory = ProductCategoryID;

            IQueryable<GriffithsBikesProductMaster> productsbycategoryIQ = from p in _classDbContext.GriffithsBikesProductMaster
                                                                         select p;
            if (ProductCategoryID != 0)
            {
                productsbycategoryIQ = productsbycategoryIQ.Where(p => p.ProductCategoryID.Equals(ProductCategoryID));

               
            }
            productsbycategory = await productsbycategoryIQ.AsNoTracking().ToListAsync();

            var EmailUsername = HttpContext.Session.GetString("EmailUsername");
            var GriffithsBikesUserID = HttpContext.Session.GetString("GriffithsBikesUserID");
            var firstname = HttpContext.Session.GetString("FirstName");
            var lastname = HttpContext.Session.GetString("LastName");
            //If you want any processing to occur before the page displays in the barrier; do it here
            if (EmailUsername != null && EmailUsername != "")
            {
                Message = "Please pick your product: " + firstname + " " + lastname;
            }



        }

       

        //public int CurrentCategory { get; set; }
        //public async Task OnGetAsync(int ProductMasterID)
        //{
        //    CurrentCategory = ProductMasterID;

        //    IQueryable<GriffithsBikesProductMaster> productsbycategoryIQ = from p in _classDbContext.GriffithsBikesProductMaster
        //                                                                   select p;

        //    if (ProductMasterID != 0)
        //    {
        //    productsbycategoryIQ = productsbycategoryIQ.Where(p => p.ProductMasterID.Equals(ProductMasterID));
        //    }

        //productsbycategoryIQ = await productsbycategoryIQ.AsNoTracking().ToListAsync();
        //}
    }
}





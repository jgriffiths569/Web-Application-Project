using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using System.Data;


namespace GriffithsBikes.Pages
{
    public class CreateNewUserModel : PageModel
    {
        [BindProperty]
        public string EmailUserName { get; set; }
        [BindProperty]
        public string ConfirmUserPassword { get; set; }
        [BindProperty]
        public string FirstName { get; set; }
        [BindProperty]
        public string LastName { get; set; }
        [BindProperty]
        public string UserPhoneNumber { get; set; }
        [BindProperty]
        public string UserPassword { get; set; }

        
        public string Message { get; set; }

        
        public string MessageColor { get; set; }

        private readonly IConfiguration configuration;

        public CreateNewUserModel(IConfiguration _configuration)
        {
            configuration = _configuration;
        }

        public void OnGet()
        {
        }

        public IActionResult OnPostCreate()
        {
            if (ModelState.IsValid)
            {
                //Get our connection string from appsettings.json
                var strConn = configuration.GetConnectionString("DefaultConnection");

                //Create an instance of the class equal connection
                using SqlConnection sqlConn = new(strConn);

                SqlCommand CreateUserCmd = new SqlCommand("spNewUserFa22", sqlConn);
                CreateUserCmd.CommandType = CommandType.StoredProcedure;

                //build your input parameters.
                CreateUserCmd.Parameters.AddWithValue("@FirstName", FirstName);
                CreateUserCmd.Parameters.AddWithValue("@LastName", LastName);
                CreateUserCmd.Parameters.AddWithValue("@UserPhoneNumber", UserPhoneNumber);
                CreateUserCmd.Parameters.AddWithValue("@EmailUsername", EmailUserName);
                CreateUserCmd.Parameters.AddWithValue("@UserPassword", UserPassword);

                try
                {
                    //Open the database.
                    sqlConn.Open();

                    //Execute the stored procedure.
                    CreateUserCmd.ExecuteNonQuery();

                    //Create a success message to the user, then take them to the login page.
                    string NewUserMessage = "User was successfully added. Please login.";
                    HttpContext.Session.SetString("NewUserMessage", NewUserMessage);

                    //Clear the form.
                    FirstName = string.Empty;
                    LastName = string.Empty;
                    UserPhoneNumber = string.Empty;
                    EmailUserName = string.Empty;
                    UserPassword = string.Empty;
                    ConfirmUserPassword = string.Empty;
                    Message = string.Empty;
                    MessageColor = string.Empty;
                    ModelState.Clear();

                    //Redirect to login page.
                    return Redirect("/");

                }
                catch (Exception exc)
                {
                    Message = exc.Message;
                    return Page();

                }
            }
            else
            {
                //Validation did not pass on the form.
                return Page();
            }
        }
    }
}

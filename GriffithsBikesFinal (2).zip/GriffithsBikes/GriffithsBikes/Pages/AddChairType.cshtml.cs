using GriffithsBikes.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using Microsoft.Data.SqlClient;
using System.Data;

namespace GriffithsBikes.Pages
{

    public class AddChairTypeModel : PageModel
    {
        [BindProperty]


        [Display(Name = "Chair Type Name")]
        [Required(ErrorMessage = "Please enter a Chair Type Name")]
        [StringLength(50)]
        public string TypeName { get; set; } = String.Empty;
        public ChairType MyChairType { get; set; }
        public string Message { get; set; } = String.Empty;

        private readonly IConfiguration configuration;

        public AddChairTypeModel(IConfiguration _configuration)
        {
            configuration = _configuration;
        }
        public void OnGet()
        {
        }

        public IActionResult OnPostAdd()
        {
            //Check if the ModelState is valid, validation passed
            if (ModelState.IsValid)
            {
                // Connect to our database
                var strConn = configuration.GetConnectionString("DefaultConnection");

                //Create an instance of a SqlConnection class
                using SqlConnection sqlConn = new(strConn);
                SqlCommand AddChairCmd = new SqlCommand("spInsertChairType", sqlConn);
                AddChairCmd.CommandType = CommandType.StoredProcedure;

                //Build our input parameter.
                AddChairCmd.Parameters.AddWithValue("@TypeName", TypeName);

                try
                {
                    //Open the dataabase
                    sqlConn.Open();

                    //Use ExecuteNonQuery to execute our stored procedure.
                    AddChairCmd.ExecuteNonQuery();

                    Message = "Type was successfully added.";

                    TypeName = String.Empty;
                    ModelState.Clear();

                    //Return the page.
                    return Page();
                }
                catch (Exception exc)
                {

                    Message = exc.Message;
                    return Page();
                }
            }
            else
            {
                return Page();
            }
        }
    }
}

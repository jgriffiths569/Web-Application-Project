﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GriffithsBikes.Pages
{
  
    public class HomePageModel : PageModel
    {
        public string Fullname { get; set; }
        public string Message { get; set; }
        private readonly ILogger<HomePageModel> _logger;

        public HomePageModel(ILogger<HomePageModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            var EmailUsername = HttpContext.Session.GetString("EmailUsername");
            var GriffithsBikesUserID = HttpContext.Session.GetString("GriffithsBikesUserID");
            var firstname = HttpContext.Session.GetString("FirstName");
            var lastname = HttpContext.Session.GetString("LastName");
            //If you want any processing to occur before the page displays in the barrier; do it here
            if (EmailUsername != null && EmailUsername != "")
            {
                Message = "My accountid is " + GriffithsBikesUserID + " and my username is " + EmailUsername;
                Fullname = "Welcome! " + firstname + " " + lastname;
            }
        }
    }
}
using GriffithsBikes.Data;
using GriffithsBikes.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GriffithsBikes.Pages
{
    public class CategoryPage2Model : PageModel
    {
        private readonly ClassDbContext _classDbContext;
        public string Fullname { get; set; }
        public string Message { get; set; }
        public CategoryPage2Model(ClassDbContext classDbContext)
        {
            _classDbContext = classDbContext;
        }

        public string CurrentCategory { get; set; }
        public IList<GriffithsBikesProductCategory> categories { get; set; }
        public void OnGet()
        {
            categories = _classDbContext.GriffithsBikesProductCategory.ToList();

            var EmailUsername = HttpContext.Session.GetString("EmailUsername");
            var GriffithsBikesUserID = HttpContext.Session.GetString("GriffithsBikesUserID");
            var firstname = HttpContext.Session.GetString("FirstName");
            var lastname = HttpContext.Session.GetString("LastName");
            //If you want any processing to occur before the page displays in the barrier; do it here
            if (EmailUsername != null && EmailUsername != "")
            {
                Message = "Please select a category: " + firstname + " " + lastname;
            }
        }
    }
}

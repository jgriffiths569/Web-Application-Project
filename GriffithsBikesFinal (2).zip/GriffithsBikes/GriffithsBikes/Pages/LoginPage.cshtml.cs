using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using Microsoft.Data.SqlClient;
using System.Data;
using GriffithsBikes.Entities;

namespace GriffithsBikes.Pages
{
    public class LoginPageModel : PageModel
    {
        public string Message { get; set; } = string.Empty;
        public string MessageColor { get; set; } = "Green";
        //The following is added for bound html element on the Razor page
        //SHORTCUT: type 'prop' and then tab twice
        [BindProperty]
        //[Display(Name = "Email Address")]
        [Required(ErrorMessage = "Please enter an email address.")]
        //[RegularExpression(@"\S+\@\S+\.\S+", ErrorMessage = "Please enter a valid email address.")]


        public string EmailAddress { get; set; } = String.Empty;

        [BindProperty]
        [Display(Name = "Password")]
        [RegularExpression(@"\S{5,10}", ErrorMessage = "Please enter a password that contains " + "between 5 and 10 non-blank characters.")]
        [Required(ErrorMessage = "Please enter a password.")]
        [StringLength(10)]

        public string Password { get; set; } = String.Empty;

        private readonly IConfiguration configuration;

        public LoginPageModel(IConfiguration _configuration)
        {
            configuration = _configuration;
        }
         

        public void OnGet()
        {
            //Get the values from the database and display on page
            string strTempMessage = HttpContext.Session.GetString("NewUserMessage");

            if (strTempMessage != null)
            {
                Message = strTempMessage;
            }
           
        }

        //Add the following handler method for when the form is posted
        //(i.e., the submit button is clicked)
        //The 'Login' part has to match the word in the asp-page-handler value on Razor page
        public IActionResult OnPostLogin()
        {
            //Get the connectoin to your database using the name value that you created and your appsettings.json file
            var strConn = configuration.GetConnectionString("DefaultConnection");

            //Create an instance of the SQLConnectioin class.
            using (SqlConnection sqlConn = new(strConn))
            {
                //Use a SqlDataAdaptor to execute our SELECT stored procedure to validate our user credentials
                SqlDataAdapter sqldaValidateUser = new SqlDataAdapter("spValidateUser3", sqlConn);
                sqldaValidateUser.SelectCommand.CommandType = CommandType.StoredProcedure;

                //Create our input parameters
                sqldaValidateUser.SelectCommand.Parameters.AddWithValue("@EmailUsername", EmailAddress);
                sqldaValidateUser.SelectCommand.Parameters.AddWithValue("@UserPassword", Password);

                //Use a try catch to execute
                try
                {
                    DataSet dsUserRecord = new DataSet();

                    sqldaValidateUser.Fill(dsUserRecord);

                    if (dsUserRecord.Tables[0].Rows.Count == 0)
                    {
                        //If count was 0, the credentials were not valid.
                        Message = "Invalid login, please try again.";
                        return Page();
                    }
                    else
                    {
                        //We found a match in the database. Credentials are valid
                        //Take the user back to thhe HOME page and display a welcome message with the user's first name.
                        //Define an instance of the AccountMaster class
                        UserMasterGriffithsBicycles currentUser = new UserMasterGriffithsBicycles();
                        currentUser.GriffithsBikesUserID = Convert.ToInt32(dsUserRecord.Tables[0].Rows[0]["GriffithsBikesUserID"]);
                        currentUser.FirstName = dsUserRecord.Tables[0].Rows[0]["FirstName"].ToString();
                        currentUser.LastName = dsUserRecord.Tables[0].Rows[0]["LastName"].ToString();
                        currentUser.EmailUsername = dsUserRecord.Tables[0].Rows[0]["EmailUsername"].ToString();

                        //Save the information into session variables.
                        HttpContext.Session.SetString("GriffithsBikesUserID", currentUser.GriffithsBikesUserID.ToString());
                        HttpContext.Session.SetString("FirstName", currentUser.FirstName.ToString());
                        HttpContext.Session.SetString("LastName", currentUser.LastName.ToString());
                        HttpContext.Session.SetString("EmailUsername", currentUser.EmailUsername.ToString());

                        //Clear the form.
                        EmailAddress = String.Empty;
                        Password = String.Empty;
                        ModelState.Clear();

                        return Redirect("/HomePage");
                    }
                }
                catch (Exception exc)
                {

                    Message = exc.Message;
                    MessageColor = "Red";
                    return Page();
                }
            }
         
        }
        public IActionResult OnPostCancel()
        {
            ModelState.Clear();
            EmailAddress = String.Empty;
            Password = String.Empty;
            return Page();
        }
    }
}
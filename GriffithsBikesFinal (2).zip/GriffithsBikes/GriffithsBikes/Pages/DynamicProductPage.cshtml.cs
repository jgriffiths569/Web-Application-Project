using GriffithsBikes.Data;
using Microsoft.AspNetCore.Mvc;
using GriffithsBikes.Entities;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DynamicProductPageRecording.Entities;

namespace GriffithsBikes.Pages
{

    public class DynamicProductPageModel : PageModel
    {
            //Do the following to inject our Database context into our Razor Page model.
            private readonly ClassDbContext _classDbContext;
            public DynamicProductPageModel(ClassDbContext classDbContext)
            {
                _classDbContext = classDbContext;
            }
            
            
            public IList<GriffithsBikesProductMaster> allproducts { get; set; }



        public void OnGet()
        {
            allproducts = _classDbContext.GriffithsBikesProductMaster.ToList();
        }
            

        
    }

    //public int CurrentCategory { get; set; }
    //public async Task OnGetAsync(int ProductMasterID)
    //{
    //    CurrentCategory = ProductMasterID;

    //    IQueryable<GriffithsBikesProductMaster> productsbycategoryIQ = from p in _classDbContext.GriffithsBikesProductMaster
    //                                                                   select p;

    //    if (ProductMasterID != 0)
    //    {
    //    productsbycategoryIQ = productsbycategoryIQ.Where(p => p.ProductMasterID.Equals(ProductMasterID));
    //    }

    //productsbycategoryIQ = await productsbycategoryIQ.AsNoTracking().ToListAsync();
    //}
}





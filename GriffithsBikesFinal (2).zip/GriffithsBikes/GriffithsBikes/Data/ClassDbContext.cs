﻿using Microsoft.EntityFrameworkCore;
using System.Data;
using Microsoft.Data.SqlClient;
using GriffithsBikes.Entities;
using DynamicProductPageRecording.Entities;

namespace GriffithsBikes.Data
{
    public class ClassDbContext : DbContext
    {
        public ClassDbContext(DbContextOptions<ClassDbContext> options) : base(options)
        {
        }

        public DbSet<GriffithsBikesProductMaster> GriffithsBikesProductMaster { get; set; }
        public DbSet<GriffithsBikesProductCategory> GriffithsBikesProductCategory { get; set; }
    }
}

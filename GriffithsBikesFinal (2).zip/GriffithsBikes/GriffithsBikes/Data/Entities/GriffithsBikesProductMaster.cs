﻿using System.ComponentModel.DataAnnotations;

namespace DynamicProductPageRecording.Entities
{
    public class GriffithsBikesProductMaster
    {
        [Key]
        public int ProductMasterID { get; set; }
        public string ProductName { get; set; }
        public string ProductPrice { get; set; }
        public string ProductColor { get; set; }
        public string ProductImage { get; set; }
        public string ProductSize { get; set; }
        public int ProductCategoryID { get; set; }

    }
}

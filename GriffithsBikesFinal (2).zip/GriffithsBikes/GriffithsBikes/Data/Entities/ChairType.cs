﻿namespace GriffithsBikes.Entities
{
    public class ChairType
    {
        public string TypeName { get; set; }
    }
}

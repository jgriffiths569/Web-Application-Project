﻿namespace GriffithsBikes.Entities
{
    public class CreateNewUser
    {
        public int GriffithsBikesUserID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserPassword { get; set; }
        public string EmailUsername { get; set; }
        public string UserPhoneNumber { get; set; }
    }
}

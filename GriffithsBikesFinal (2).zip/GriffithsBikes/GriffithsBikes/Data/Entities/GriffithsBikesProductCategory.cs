﻿using System.ComponentModel.DataAnnotations;


namespace GriffithsBikes.Entities
{
    public class GriffithsBikesProductCategory
    {
        [Key]
        public int ProductCategoryID { get; set; }
        public string ProductCategoryName { get; set; }
        public string ProductCategoryDesc { get; set; }
    }
}
